// swift-tools-version: 6.0

import PackageDescription

let package = Package(
    name: "App1",
    platforms: [
        .iOS(.v17),
        .macOS(.v14),
    ],
    products: [
        // An xtool project should contain exactly one library product,
        // representing the main app.
        .library(
            name: "App1",
            targets: ["App1"]
        ),
    ],
    targets: [
        .target(
            name: "App1",
            resources: [
                .process("Resources")
            ]
        ),
    ]
)
