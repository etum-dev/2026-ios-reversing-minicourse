import SwiftUI
#if canImport(UIKit)
import UIKit
#elseif canImport(AppKit)
import AppKit
#endif

extension Image {
    init(bundleFile name: String, extension ext: String) {
        guard let url = Bundle.module.url(forResource: name, withExtension: ext) else {
            self.init(systemName: "photo")
            return
        }
        #if canImport(UIKit)
        if let uiImage = UIImage(contentsOfFile: url.path) {
            self.init(uiImage: uiImage)
            return
        }
        #elseif canImport(AppKit)
        if let nsImage = NSImage(contentsOfFile: url.path) {
            self.init(nsImage: nsImage)
            return
        }
        #endif
        self.init(systemName: "photo")
    }
}
