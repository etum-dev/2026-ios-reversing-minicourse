import SwiftUI

@main
struct App1App: App {
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
