import SwiftUI
import SwiftData

/// The main wishlist view displaying trip-related content.
///
/// This view serves as the primary interface for browsing trips in
/// a vertically scrolling layout.
struct FridgeView: View {
        var body: some View {
        VStack {
            Text("Found some food")
            Image(bundleFile: "PipiCarrot", extension: "jpeg").resizable().aspectRatio(contentMode: .fit)
        }
    }

}