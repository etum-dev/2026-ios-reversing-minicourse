import SwiftUI
import SwiftData

/// The main wishlist view displaying trip-related content.
///
/// This view serves as the primary interface for browsing trips in
/// a vertically scrolling layout.
struct CupboardView: View {

    var body: some View {
        VStack {
            Text("Found some tea")
            Image(bundleFile: "BambinoMistyMint", extension: "png").resizable().aspectRatio(contentMode: .fit)
        }
    }
}