import SwiftUI
import SwiftData

struct ContentView: View {
    @State private var count = 0
    var message: String {
        count >= 10 ? "Tralalero tralala" : "tung tung sahur"
    }
    var body: some View {
        if #available(iOS 18, *){
        TabView {
            Tab("Drinkellini", systemImage: "heart.fill") {
                CupboardView()
            }
            Tab("Foodini", systemImage:"tray.full") {
                FridgeView()
            }
        } 
        

            VStack {
                Button("Tap") {
                    
                    print("button was tapped")
                    count += 1
                }
                Text(message)

                
            }
            .padding()
        
        }
    }
}
